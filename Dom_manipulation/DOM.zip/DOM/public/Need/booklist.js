import { bookarray } from "./book.js";
for (let index = 0; index < bookarray.length; index++) {
    bookarray[index].display(index + 1);
}
